/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp8_nuñez_emilia;

/**
 *
 * @author emi
 */
public class TP8_Nuñez_Emilia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Frame f = new Frame();
       f.setVisible(true);
    }
    
}
