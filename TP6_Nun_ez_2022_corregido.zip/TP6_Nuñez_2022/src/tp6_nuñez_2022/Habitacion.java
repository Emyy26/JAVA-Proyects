/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6_nuñez_2022;

import java.util.ArrayList;

/**
 *
 * @author emi
 */
public class Habitacion {
    private int nro;
    private ArrayList<Huesped> huespedes;
    private int capacidad;

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public ArrayList<Huesped> getHuespedes() {
        return huespedes;
    }

    public void setHuespedes(ArrayList<Huesped> huespedes) {
        this.huespedes = huespedes;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public Habitacion(){
        this.setNro(0);
        this.setHuespedes(new ArrayList<Huesped>());
        this.setCapacidad(0);
    }
}
