/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp7_nuñez_2022;

import java.util.ArrayList;

/**
 *
 * @author emi
 */
public class Habitacion {
    private int nro;
    private ArrayList<Producto> productos;
    private ArrayList<Servicio> servicios;
    private double precio;
    private double totalServicios;
    private double totalProductos;

    public double getTotalServicios() {
        return totalServicios;
    }

    public void setTotalServicios(double totalServicios) {
        this.totalServicios = totalServicios;
    }

    public double getTotalProductos() {
        return totalProductos;
    }

    public void setTotalProductos(double totalProductos) {
        this.totalProductos = totalProductos;
    }

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public ArrayList<Servicio> getServicios() {
        return servicios;
    }

    public void setServicios(ArrayList<Servicio> servicios) {
        this.servicios = servicios;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Habitacion(){
        this.setNro(0);
        this.setProductos(new ArrayList<Producto>());
        this.setServicios(new ArrayList<Servicio>());
        this.setPrecio(0);
    }
    
    /**
     * Metodo que recorre los productos de la habitacion
     * y obtiene la suma del importe de cada producto
     * consumido en la habitacion, por ultimo retorna
     * el importe total de productos ocupados en la habitacion
     * @return 
     */
    public double getTotalDeProductos(){
        double total = 0.d;
        if(getProductos()==null
                || getProductos().size()==0){
            return total;
        }
        for(int index=0;index<getProductos().size();index++){
            Producto p = getProductos().get(index);
            total = total + (p.getCantidad() * p.getPrecio());
        }
        return total;
    }
}
