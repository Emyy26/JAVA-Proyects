/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp7_nuñez_2022;

/**
 *
 * @author emi
 */
public class TP7_Nuñez_2022 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Frame f = new Frame();
       f.setVisible(true);
    }
    
}
