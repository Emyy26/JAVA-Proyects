/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1_nuñez_2022;

/**
 *
 * @author emi
 */
public class Vendedor extends Empleado{
    
    //se agrega un atributo
    private String oficio = "Vendedor";

    //se crea el método get
    public String getOficio() {
        return oficio;
    }

    //se crea el método set
    public void setOficio(String oficio) {
        this.oficio = oficio;
    }

    //se crea un constructor
    public Vendedor(double porcentaje, double salario) {
        super(porcentaje, salario);
    }
    
    //se sobreescribe el método de calcularAguinaldo. 
    @Override
    public double calcularAguinaldo() {
        double aguinaldo = (getSalario() * getPorcentaje()) / 100;
        return aguinaldo;
    }
}
