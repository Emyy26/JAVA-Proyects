/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1_nuñez_2022;

/**
 *
 * @author emi
 */
public class Servicio {
    
    //se crean los atributos.
    private double tarifa = 5.00d;
    private int tiempo;
    
    //se crea un constructor.
    public Servicio(int tiempo){
        this.tiempo = tiempo;
    }

    //se crea el método get.
    public double getTarifa() {
        return tarifa;
    }

    //se crea el método set.
    public void setTarifa(double tarifa) {
        this.tarifa = tarifa;
    }

    //se crea el método get.
    public int getTiempo() {
        return tiempo;
    }

    //se crea el método set.
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }
}
