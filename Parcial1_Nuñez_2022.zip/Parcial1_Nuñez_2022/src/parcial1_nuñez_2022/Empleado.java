/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1_nuñez_2022;

/**
 *
 * @author emi
 */
//se crea una clase abstracta.
public abstract class Empleado {
    private String nombre;
    private double salario;
    private double porcentaje;

    //se crea el método get.
    public String getNombre() {
        return nombre;
    }

    //se crea el método set.
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //se crea el método get.
    public double getSalario() {
        return salario;
    }

    //se crea el método set.
    public void setSalario(double salario) {
        this.salario = salario;
    }

    //se crea el método get.
    public double getPorcentaje() {
        return porcentaje;
    }

    //se crea el método set.
    public void setPorcentaje(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    //se crea un constructor.
    public Empleado(double porcentaje, double salario) {
        this.porcentaje = porcentaje;
        this.salario = salario;
    }
    
    //se crea un metodo abstracto.
    public abstract double calcularAguinaldo();

}