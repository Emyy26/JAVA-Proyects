/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1_nuñez_2022;

import java.util.ArrayList;

/**
 *
 * @author emi
 */
public class Habitacion {
    
    //se crean los atributos
    private int nro;
    private ArrayList<Insumo> insumos;
    private ArrayList<Servicio> servicios;

    //se crea el método get
    public int getNro() {
        return nro;
    }

    //se crea el método set
    public void setNro(int nro) {
        this.nro = nro;
    }

    //se crea el método get
    public ArrayList<Insumo> getInsumos() {
        return insumos;
    }

    //se crea el método set
    public void setInsumos(ArrayList<Insumo> insumos) {
        this.insumos = insumos;
    }

    //se crea el método get
    public ArrayList<Servicio> getServicios() {
        return servicios;
    }
    
    //se crea el método set
    public void setServicios(ArrayList<Servicio> servicios) {
        this.servicios = servicios;
    } 

    //se crea un constructor
    public Habitacion(int nro) {
        this.nro = nro;
        this.servicios = new ArrayList<>();
        this.insumos = new ArrayList<>();
    }

   
    //Metodo para sumar todos los insumos del array.
    public double TotalDeInsumos(){
        double total = 0.d;
        if(getInsumos()==null|| getInsumos().isEmpty()){
            return total;
        }
        for(int i=0;i<getInsumos().size();i++){
            Insumo in = getInsumos().get(i);
            total += in.getPrecio();
        }
        return total;
    }
    
   /*Metodo que recorre el servicio de la habitacion y obtiene el precio del servicio, 
    multiplicando la tarifa por el tiempo.*/
   
    public double TotalDeServicios(){
        double total = 0.d;
        if(getServicios()==null|| getServicios().isEmpty()){
            return total;
        }
        for(int i=0;i<getServicios().size();i++){
            Servicio s = getServicios().get(i);
            total =(s.getTarifa() * s.getTiempo());
        }
        return total;
    }
}
