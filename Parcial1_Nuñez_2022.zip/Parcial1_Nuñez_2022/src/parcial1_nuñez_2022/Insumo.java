/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1_nuñez_2022;

/**
 *
 * @author emi
 */
public class Insumo {
    
    //se crean los atributos.
    private String nombre;
    private double precio;
    
    //se crea un constructor.
    public Insumo(String nombre,double precio){
        this.nombre = nombre;
        this.precio = precio;
    }

    //se crea el método get.
    public String getNombre() {
        return nombre;
    }

    //se crea el método set.
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //se crea el método get.
    public double getPrecio() {
        return precio;
    }

    //se crea el método set.
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
}
