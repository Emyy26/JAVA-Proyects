/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1_nuñez_2022;

/**
 *
 * @author emi
 */
public class Calculadora {
    //se crea el método para sumar los enteros.
    public int sumaEntero(int... nums){
        int sum = 0;
        for ( int x : nums ) {
            sum += x;
        }
        return sum;
    }
     //se crea el método para restar los numeros float.
    public float restaFloat(float a, float b){
        return a - b;
    }
    
     //se crea el método para dividir los números double.
    public double divisionDouble(double a, double b){
        return a / b;
    }
    
    //se crea el método para multiplicar los enteros.
    public int multiEntero(int a, int b){
        return a * b;
    }
    
     //se crea el método para calcular el promedio de los números double.
    public double promDouble(double... nums){
        double sum = 0;
        for ( double x : nums ) {
            sum += x;
        }
        return ((double) sum) / nums.length;
    }
    
    //se crea el método para buscar el máximo de los números double.
    public double maxDouble(double... nums){
        double max = 0;
        for ( double x : nums ) {
            if (x > max){
            max = x;
            }
        }
        return max;
    }
    
    //se crea el método para buscar el mínimo de los números enteros.
    public int minEntero(int... nums){
        int min = 9999999;
        for ( int x : nums ) {
            if (x < min){
                min = x;
            }
        }
        return min;
    }
    
}
