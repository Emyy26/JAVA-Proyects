/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp5_nuñez_2022;

import java.util.ArrayList;

/**
 *
 * @author emi
 */
public class Alumno {
    public  String nombre;

    public double getPromedio() {
        return promedio;
    }
    private ArrayList<Double> notas = new ArrayList<>();
    public  double promedio;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Double> getNotas() {
        return notas;
    }

    public void setNotas(ArrayList<Double> notas) {
        this.notas = notas;
    }


    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public Double calcularPromedio(ArrayList<Double> notas){
        Double prom = 0.d;
        Double suma = 0.d;
        for(int index=0;index<notas.size();index++){
            Double nota = notas.get(index);
            suma = suma + nota;
        }
        prom = suma / notas.size();
        return prom;
    }
    
    /**
     * Metodo que retorna el promedio de notas previamente cargadas
     * @return 
     */
    public Double calcularPromedioDeEjemplo(){
        Double prom = 0.d;
        /*Aca consulto si tengo notas para hacer calculos luego,
        sino, solo retorno el valor de prom que inicialmente esta en 0.d
        */
        if(getNotas()==null
                || getNotas().size()==0){
            return prom;
        }
        ArrayList<Double> notas = getNotas();
        Double suma = 0.d;
        for(int index=0;index<notas.size();index++){
            Double nota = notas.get(index);
            suma = suma + nota;
        }
        prom = suma / notas.size();
        return prom;
    }
}
